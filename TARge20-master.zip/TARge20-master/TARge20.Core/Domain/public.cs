﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
   public class Public
    {
        public Guid Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public Guid IdentityNumber { get; set; }
        public string Status { get; set; }

    }
}
