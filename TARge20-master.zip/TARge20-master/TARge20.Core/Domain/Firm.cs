﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Firm
    {
        [Key]
        public Guid RegistryNumber { get; set; }
        public string FirmName { get; set; }
        public string ShortName { get; set; }
        public string Address { get; set; }
        
        public string ContactPerson { get; set; }
        [ForeignKey("ContactNumber")]
        public string ContactNumber { get; set; }
        [ForeignKey("ContactEmail")]
        public string ContactEmail { get; set; }

    }
}
