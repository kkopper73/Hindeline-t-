﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace TARge20.Data.Migrations
{
    public partial class Databse : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_Sicknote",
                table: "Sicknote");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Vacation",
                table: "Vacation");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Health_Insepction",
                table: "Health_Insepction");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Children",
                table: "Children");

            migrationBuilder.DropColumn(
                name: "Frequency",
                table: "Sicknote");

            migrationBuilder.DropColumn(
                name: "Occupation",
                table: "Jobtitle");

            migrationBuilder.DropColumn(
                name: "Sector",
                table: "Jobtitle");

            migrationBuilder.DropColumn(
                name: "WorkedUntil",
                table: "Employee");

            migrationBuilder.RenameTable(
                name: "Sicknote",
                newName: "SickNote");

            migrationBuilder.RenameTable(
                name: "Vacation",
                newName: "Vacations");

            migrationBuilder.RenameTable(
                name: "Health_Insepction",
                newName: "Health_Insepctions");

            migrationBuilder.RenameTable(
                name: "Children",
                newName: "Childrens");

            migrationBuilder.RenameColumn(
                name: "Reason",
                table: "SickNote",
                newName: "reason");

            migrationBuilder.AddColumn<string>(
                name: "Department",
                table: "Jobtitle",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Job",
                table: "Jobtitle",
                nullable: true);

            migrationBuilder.AlterColumn<DateTime>(
                name: "WorkedSince",
                table: "Employee",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<string>(
                name: "ContactNumber",
                table: "Employee",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddColumn<DateTime>(
                name: "WorkedUntill",
                table: "Employee",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AlterColumn<DateTime>(
                name: "StartsAt",
                table: "Vacations",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<DateTime>(
                name: "EndsAt",
                table: "Vacations",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddPrimaryKey(
                name: "PK_SickNote",
                table: "SickNote",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Vacations",
                table: "Vacations",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Health_Insepctions",
                table: "Health_Insepctions",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Childrens",
                table: "Childrens",
                column: "Id");

            migrationBuilder.CreateTable(
                name: "Firms",
                columns: table => new
                {
                    RegistryNumber = table.Column<Guid>(nullable: false),
                    FirmName = table.Column<string>(nullable: true),
                    ShortName = table.Column<string>(nullable: true),
                    Address = table.Column<string>(nullable: true),
                    ContactPerson = table.Column<string>(nullable: true),
                    ContactNumber = table.Column<string>(nullable: true),
                    ContactEmail = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Firms", x => x.RegistryNumber);
                });

            migrationBuilder.CreateTable(
                name: "Public",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    FirstName = table.Column<string>(nullable: true),
                    LastName = table.Column<string>(nullable: true),
                    IdentityNumber = table.Column<Guid>(nullable: false),
                    Status = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Public", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tips",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    FirstName = table.Column<string>(nullable: true),
                    LastName = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tips", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Firms");

            migrationBuilder.DropTable(
                name: "Public");

            migrationBuilder.DropTable(
                name: "Tips");

            migrationBuilder.DropPrimaryKey(
                name: "PK_SickNote",
                table: "SickNote");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Vacations",
                table: "Vacations");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Health_Insepctions",
                table: "Health_Insepctions");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Childrens",
                table: "Childrens");

            migrationBuilder.DropColumn(
                name: "Department",
                table: "Jobtitle");

            migrationBuilder.DropColumn(
                name: "Job",
                table: "Jobtitle");

            migrationBuilder.DropColumn(
                name: "WorkedUntill",
                table: "Employee");

            migrationBuilder.RenameTable(
                name: "SickNote",
                newName: "Sicknote");

            migrationBuilder.RenameTable(
                name: "Vacations",
                newName: "Vacation");

            migrationBuilder.RenameTable(
                name: "Health_Insepctions",
                newName: "Health_Insepction");

            migrationBuilder.RenameTable(
                name: "Childrens",
                newName: "Children");

            migrationBuilder.RenameColumn(
                name: "reason",
                table: "Sicknote",
                newName: "Reason");

            migrationBuilder.AddColumn<string>(
                name: "Frequency",
                table: "Sicknote",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Occupation",
                table: "Jobtitle",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Sector",
                table: "Jobtitle",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "WorkedSince",
                table: "Employee",
                type: "int",
                nullable: false,
                oldClrType: typeof(DateTime));

            migrationBuilder.AlterColumn<int>(
                name: "ContactNumber",
                table: "Employee",
                type: "int",
                nullable: false,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AddColumn<int>(
                name: "WorkedUntil",
                table: "Employee",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AlterColumn<int>(
                name: "StartsAt",
                table: "Vacation",
                type: "int",
                nullable: false,
                oldClrType: typeof(DateTime));

            migrationBuilder.AlterColumn<int>(
                name: "EndsAt",
                table: "Vacation",
                type: "int",
                nullable: false,
                oldClrType: typeof(DateTime));

            migrationBuilder.AddPrimaryKey(
                name: "PK_Sicknote",
                table: "Sicknote",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Vacation",
                table: "Vacation",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Health_Insepction",
                table: "Health_Insepction",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Children",
                table: "Children",
                column: "Id");
        }
    }
}
